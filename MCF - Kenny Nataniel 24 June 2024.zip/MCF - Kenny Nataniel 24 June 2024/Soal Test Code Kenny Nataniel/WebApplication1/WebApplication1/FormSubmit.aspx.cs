﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class FormSubmit : System.Web.UI.Page
    {
        private string username = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedInUsername"] != null)
            {
                username = Session["LoggedInUsername"].ToString();
            }

            FillStorageLocationsDropdown();
        }

        private void FillStorageLocationsDropdown()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;
            string query = "SELECT location_id, location_name FROM ms_storage_location";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlLokasiPenyimpanan.DataSource = reader;
                    ddlLokasiPenyimpanan.DataTextField = "location_name";
                    ddlLokasiPenyimpanan.DataValueField = "location_id";
                    ddlLokasiPenyimpanan.DataBind();

                    con.Close();
                }
            }

            ddlLokasiPenyimpanan.Items.Insert(0, new ListItem("Select Lokasi Penyimpanan", ""));
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session.Remove("LoggedInUsername");
            Response.Redirect("~/FormLogin.aspx");
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string agreementNumber = txtAgreementNumber.Text;
            string bpkbNo = txtNoBPKB.Text.Trim();
            string branchId = txtBranchId.Text.Trim();

            string dateValueIn = dateTanggalBPKBIn.Text; 
            DateTime dateTanggalIn = DateTime.Parse(dateValueIn);

            string dateValueBPKB = dateTanggalBPKB.Text;
            DateTime dateTanggalBPKBDate = DateTime.Parse(dateValueBPKB);

            string fakturNo = txtNoFaktur.Text.Trim();
            DateTime fakturDate = DateTime.Parse(dateTanggalFaktur.Text);
            string locationId = Convert.ToString(ddlLokasiPenyimpanan.SelectedIndex + 1);
            string policeNo = txtNomorPolisi.Text.Trim();

            string createdBy = username; 
            DateTime createdOn = DateTime.Now;
            string lastUpdatedBy = createdBy;
            DateTime lastUpdateOn = createdOn;

            string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;
            string query = @"INSERT INTO tr_bpkb 
                            (agreement_number, bpkb_no, branch_id, bpkb_date_in, bpkb_date, faktur_no, faktur_date, location_id, police_no, created_by, created_on, last_updated_by, last_update_on) 
                            VALUES 
                            (@agreementNumber, @bpkbNo, @branchId, @bpkbDateIn, @bpkbDate, @fakturNo, @fakturDate, @locationId, @policeNo, @createdBy, @createdOn, @lastUpdatedBy, @lastUpdateOn)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@agreementNumber", agreementNumber);
                    cmd.Parameters.AddWithValue("@bpkbNo", bpkbNo);
                    cmd.Parameters.AddWithValue("@branchId", branchId);
                    cmd.Parameters.AddWithValue("@bpkbDateIn", dateTanggalIn);
                    cmd.Parameters.AddWithValue("@bpkbDate", dateTanggalBPKBDate);
                    cmd.Parameters.AddWithValue("@fakturNo", fakturNo);
                    cmd.Parameters.AddWithValue("@fakturDate", fakturDate);
                    cmd.Parameters.AddWithValue("@locationId", locationId);
                    cmd.Parameters.AddWithValue("@policeNo", policeNo);
                    cmd.Parameters.AddWithValue("@createdBy", createdBy);
                    cmd.Parameters.AddWithValue("@createdOn", createdOn);
                    cmd.Parameters.AddWithValue("@lastUpdatedBy", lastUpdatedBy);
                    cmd.Parameters.AddWithValue("@lastUpdateOn", lastUpdateOn);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {
                        Response.Write("<script>alert('Data saved successfully.');</script>");
                        Response.Redirect("FormSubmit.aspx");
                    }
                }
            }

        }
    }
}