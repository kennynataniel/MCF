﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Model;

namespace WebApplication1
{
    public partial class FormLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            ms_user newUser = new ms_user();

            newUser.UserName = txtUsername.Text;
            newUser.Password = txtPassword.Text;
            newUser.IsActive = true;

            DatabaseHelper db = new DatabaseHelper();
            db.AddUser(newUser);

            Session["LoggedInUsername"] = newUser.UserName;

            lblMessage.Text = "Login berhasil!";
            lblMessage.ForeColor = System.Drawing.Color.Green;

            Response.Redirect("FormSubmit.aspx");

        }
    }
}